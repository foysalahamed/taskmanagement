package com.jwt.jwt.todo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Profile {
	
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private Gender gender;
	private String skillField;
	private String email;
	private String mobile;
	private String username;
	private Date regiDate;
	
	
	protected Profile() {
		
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Gender getGender() {
		return gender;
	}


	public void setGender(Gender gender) {
		this.gender = gender;
	}


	public String getSkillField() {
		return skillField;
	}


	public void setSkillField(String skillField) {
		this.skillField = skillField;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}




	public Date getRegiDate() {
		return regiDate;
	}


	public void setRegiDate(Date regiDate) {
		this.regiDate = regiDate;
	}
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	@Override
	public String toString() {
		return "Profile [id=" + id + ", name=" + name + ", gender=" + gender + ", skillField=" + skillField + ", email="
				+ email + ", mobile=" + mobile + ", username=" + username + ", regiDate=" + regiDate + "]";
	}


	
}
